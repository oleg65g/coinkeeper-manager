<?php
$ONL = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `viz` > '".(time()-$sql['s_online'])."'"),0);
if(!$user['id']) {
echo '<div class="center" style="padding-top: 12px;"><font color=#2b572f size=2>';

echo ' | '.round(microtime(1) - $t, 3).' сек';
echo ' | '.$today[1].'<br>';
echo '<div style="padding-top: 5px;">ОлегБевз © 2020, 16+</div>';
echo '</font></div><div class="ovh"><br></div>';
}else{


//echo '<div class="start mar6t">
//<div class="msg mrg_msg1 mt10 c_brown4">
//<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">';
//							
//                            
//                            
//                            
//                            
//                            
//                            
//echo'</div></div></div></div></div></div>
//</div>';

echo '<div class="marea mt5 dbmenu"><div class="bmenu">
<table class="tbmenu"><tbody><tr>';

echo '<td class="va-t "><span class="wbmenu"><a href="/">
<img src="/images/m.png" width="95%" alt="Главная ">
<span class="ttl-m green"><span class="tr"><span class="tc">Главная</span></span></span></a></span></td>';

echo '<td class="va-t "><span class="wbmenu"><a href="'.$HOME.'tikets/">
<img src="/images/t.png" width="95%" alt="Профиль">
<span class="ttl-m green"><span class="tr"><span class="tc">Поддержка</span></span></span></a></span></td>';

echo '<td class="va-t "><span class="wbmenu"><a href="/settings/">
<img src="/images/s.png" width="95%" alt="Чат">
<span class="ttl-m green"><span class="tr"><span class="tc">Настройки</span></span></span></a></span></td>';

echo '</tr></tbody></table>
</div></div><span class="arrow_up"></span>';





echo '<div class="small mt20 mb20 c_lbrown cntr td_un">
			<div class="mb10">
		
</div>

<div class="mt5 mb5">
<font color=#2b572f size=2>'.round(microtime(1) - $t, 3).' сек, '.$today[1].'</font><br>
<font color=#2b572f size=2>ОлегБевз © 2020, 16+</font><br>
<a href="'.$HOME.'tikets/" class="">';



$kolvo = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE  `status` > '0' and `tiket_m` = '1' "),0); 


   


echo'</a><br><br>
</div>
</div></div>


</div></div></div></div>';





ob_end_flush();
}







?>
</div>
</body>
<?