<?php
$NameGame = 'Coinkeeper';
?>



<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="Keywords" content="Авиа Бизнесмены, игры, RPG, MMORPG, бизнес игра, онлайн, wap, бесплатно, бизнес, играть онлайн, ролевые игры, лучшие онлайн игры, браузерная игра, самолёты, авикомпания, город, турниры, задания, авиа, аэропорт">
<meta name="google" content="notranslate">

<meta property="og:type" content="website">
<meta property="og:site_name" content="<?=$NameGame?>">
<meta property="og:title" content="<?=$NameGame?>">
<meta property="og:description" content="Построй свой виртуальный бизнес. Управляй целой Авиакомпанией из десятков самолётов, строй аэропорт мечты!">
<meta property="og:url" content="<?=$HOME?>">
<meta property="og:locale" content="ru_RU">
<meta property="og:image" content="<?=$HOME?>images/logo.jpg">
<meta property="og:image:width" content="2560">
<meta property="og:image:height" content="1024">

<link rel="icon" href="/favicon.ico" type="image/png">
<link rel="stylesheet" type="text/css" href="/diz.css"><title><?=$NameGame?></title>
 
<script type="text/javascript">
    var functionsContainer = [];
    var spellsCheckFunctionsContainer = [];
    var modalFunctionsContainer = [];
</script>

<script type="text/javascript">
var secS ='с';var secM ='сек';var minS ='м :';var minM ='мин';var hourS ='ч :';var hourM ='час';var dayS ='д :';var dayM ='дн';var detailOut = false;var readyLink = '0'+(detailOut?secS:' ' + secM);
</script>

<script type="text/javascript" data-persistent="true" src="<?=$HOME?>js/lib.js"></script>
<script type="text/javascript" data-persistent="true" src="<?=$HOME?>js/t.js"></script>



<script type="text/javascript" data-persistent="true" src="<?=$HOME?>js/js.js"></script>

<!--
<script type="text/javascript">
    window.onload = function () {
        console.log('setting globalCurrentVersion to ' + globalLastVersion);
        globalCurrentVersion = globalLastVersion;
        for (var i = 0; i < functionsContainer.length; i++) {
            functionsContainer[i]();
        }
        navigationModule.prepareAjaxPageElements(document.getElementsByTagName('body')[0]);
    }
</script>
-->



</head>












<body data-feedly-mini="yes">

        
<script type="text/javascript">
    __isIntegrated = true;
    __integrationInitialized = false;
</script>

    <script type="text/javascript">
        __isIntegrated = false;
    </script>

<script type="text/javascript">
    function ensureIntegrationInitialized(successHandler)
    {
        successHandler = typeof successHandler !== 'undefined' ? successHandler : null;

        if (!__isIntegrated) {
            return;
        }

        if (__integrationInitialized) {
            if (successHandler != null) {
                successHandler();
            }

            return;
        }

        internalInit(successHandler);
        __integrationInitialized = true;
    }

    function showShareBox(message, isTargetIM)
    {
        if (!__isIntegrated)
        {
            return;
        }

        ensureIntegrationInitialized();
        internalShowShareBox(message, isTargetIM);
    }

    function showInviteBox() {
        if (!__isIntegrated) {
            return;
        }

        ensureIntegrationInitialized();
        internalShowInviteBox();
    }
</script>



<div id="page_content" class="page_content">
<script type="text/javascript">
    globalLastVersion = 89;
    console.log('globalLastVersion is ' + globalLastVersion);
</script>

























<?php
$t = microtime(1);
$today[1] = date("H:i:s"); 


$sql = mysql_fetch_assoc(mysql_query("SELECT * FROM `settings` WHERE `id` = '1'"));



if(!$user['id']) {

if (isset($_SESSION['err'])){
?><div class="msg mrg_msg1 mt11 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<img src="/images/err.png"> <?=$_SESSION['err']?></span></div></div></div></div></div></div><?php
unset($_SESSION['err']);}

if (isset($_SESSION['ok'])){
?><div class="msg mrg_msg1 mt11 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<img src="/images/ok.png"> <?=$_SESSION['ok']?></span></div></div></div></div></div></div><?php
unset($_SESSION['ok']);}

}else{
require_once ('taimers.php');
require_once ('level_user.php');
if($ban){header('Location: '.$HOME.'ban.php');}


  
    

echo '<div class="msg mrg_msg3 mt9 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<span class="stat"><img class="price_img" src="/images/coin.png" >'.n_f($user['coin']).' гривен</span>
		<span class="separator"></span>
		
</span></div></div></div></div></div></div>'; // прогресс уровня



////
//echo '<div class="msg mrg_msg3 mt9 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
//	<table class="small h24 bold"><tbody><tr>
//			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$user['level'].'</td>
//			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$exp_progress.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
//			<td class="vm plr5 c_brown3">'.$exp_progress.'%</td>
//		</tr></tbody></table>
//</span></div></div></div></div></div></div>'; // прогресс уровня    
    
    
    
    
    
    
//echo '<div class="start mar6t">
//<div class="msg mrg_msg1 mt10 c_brown4">
//<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">';

























/*




echo '<div class="ttl green mrg_ttl1 mt10"><div class="tr"><div class="tc">Магазин / Еда</div></div></div>'; // зеленая полоса
echo '<div class="ttl purple mrg_ttl1 mt10"><div class="tr"><div class="tc">Магазин / Еда</div></div></div>'; // голубая полоса
echo '<div class="ttl rose mrg_ttl1 mt10"><div class="tr"><div class="tc">Магазин / Еда</div></div></div>'; // розовая полоса
echo '<div class="ttl lyell mrg_ttl1 mt10"><div class="tr"><div class="tc">Магазин / Еда</div></div></div>'; // оранжевый полоса





<div class="msg mrg_msg2 mt32">
						<div class="wr_bg"><div class="wr_c3 m-3"><div class="wr_c4">
							<div class="ttl mmt"><div class="tr"><div class="tc">Поздравляем!</div></div></div>
							<div class="pb5"><span class="succes"><b>Ваш питомец успешно сохранен.<br>Награда: <img class="price_img" src="/view/image/icons/coin.png">5 монет</b></span></div>
						</div></div></div>
					</div>
					
					
					
<div class="msg mrg_msg1 mt10 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="succes">Ура! Ваш питомец снова полон сил!<br><b>Награда: </b><img class="price_img" src="/view/image/icons/expirience.png">102</span></div></div></div></div></div></div>






<div class="msg mrg_msg2 mt32">
						<div class="wr_bg"><div class="wr_c3 m-3"><div class="wr_c4">
							<div class="ttl mmt"><div class="tr"><div class="tc">Новое достижение<a class="x" href="/charm?r=521"></a></div></div></div>
							<div class="pb5 td_un"><div class="c_green bold">Вы перешли в Лигу спортсменов!<div class="mt3">Награда <img class="price_img" src="/view/image/icons/coin.png" alt="">15 монет</div></div></div>
						</div></div></div>
					</div>




<div class="msg mrg_msg1 mt10 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="darkgreen_link">Ежедневный подарок <img class="price_img" src="/view/image/icons/coin.png">5 монет!<br>Приходи завтра и получишь еще монет.</span></div></div></div></div></div></div>

*/




if (isset($_SESSION['level'])){
?><div class="msg mrg_msg2 mt32"><div class="wr_bg"><div class="wr_c3 m-3"><div class="wr_c4">
<?=$_SESSION['level']?>
</div></div></div></div><?php
unset($_SESSION['level']);}

if (isset($_SESSION['coin'])){
?><div class="msg mrg_msg1 mt5 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<?=$_SESSION['coin']?></span></div></div></div></div></div></div><?php
unset($_SESSION['coin']);}

if (isset($_SESSION['baks'])){
?><div class="msg mrg_msg1 mt5 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<?=$_SESSION['baks']?></span></div></div></div></div></div></div><?php
unset($_SESSION['baks']);}

if (isset($_SESSION['ses'])){
?><div class="msg mrg_msg1 mt5 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<?=$_SESSION['ses']?></span></div></div></div></div></div></div><?php
unset($_SESSION['ses']);}





if (isset($_SESSION['err'])){
?><div class="msg mrg_msg1 mt5 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<img class="price_img" src="/images/err.png" alt=""> <span class="warning"><?=$_SESSION['err']?></span></span></div></div></div></div></div></div><?php
unset($_SESSION['err']);}

if (isset($_SESSION['ok'])){
?><div class="msg mrg_msg1 mt5 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<img src="/images/ok.png"> <?=$_SESSION['ok']?></span></div></div></div></div></div></div><?php
unset($_SESSION['ok']);}

    
       

}



if($user['time_refresh'] > time()){
$time_refresh = (($user['time_refresh']+0.5)-time());
}

if(($time_refresh) > 0){
header('Refresh: '.$time_refresh.'; url=?');
}


//echo ''.$time_refresh.'';






$coll_mis_done_1  = mysql_result(mysql_query("SELECT COUNT(*) FROM `missions_user` WHERE `user` = '".$user['id']."' and `progress_now` >= `max` and `time` = '0' and `tip` = '1' "),0);
$coll_mis_done_2  = mysql_result(mysql_query("SELECT COUNT(*) FROM `missions_user` WHERE `user` = '".$user['id']."' and `progress_now` >= `max` and `time` = '0' and `tip` = '2' "),0);

$coll_a_done_2  = mysql_result(mysql_query("SELECT COUNT(*) FROM `achievements_user` WHERE `user` = '".$user['id']."' and `done` = '1'"),0);      
//echo ''.$_SERVER['PHP_SELF'].'';

if($user['level'] >0){
if($coll_mis_done_1>0){
if ($_SERVER['PHP_SELF'] != '/missions/index.php' ) {
$_SESSION['ok_2'] = 'Заберите награду за выполненные задания!
<div class="clb"></div>
<center><a href="'.$HOME.'missions/" class="bbtn mt5 mb5 "><span class="br"><span class="bc">Простые задания</span></span></a></center>';
}
}elseif($coll_mis_done_2>0){
if ($_SERVER['PHP_SELF'] != '/missions/single.php' ) {
$_SESSION['ok_3'] = 'Заберите награду за выполненные задания!
<div class="clb"></div>
<center><a href="'.$HOME.'missionssingle/" class="bbtn mt5 mb5 "><span class="br"><span class="bc">Одноразовые задания</span></span></a></center>';
}
    

}
if($coll_a_done_2 >0){
if ($_SERVER['PHP_SELF'] != '/achievements/index.php' ) {
$_SESSION['ok_4'] = 'Заберите награду за выполненные достижения!
<div class="clb"></div>
<center><a href="'.$HOME.'achievements/" class="bbtn mt5 mb5 "><span class="br"><span class="bc">Достижения</span></span></a></center>';
}   
}  
}

?>