<?php

if($user['level'] == 1){ $exp = 25;}
elseif($user['level'] == 2){ $exp = 250;}
elseif($user['level'] == 3){ $exp = 500;}
elseif($user['level'] == 4){ $exp = 1000;}
elseif($user['level'] == 5){ $exp = 2500;}
elseif($user['level'] == 6){ $exp = 5000;}
elseif($user['level'] == 7){ $exp = 10000;}
elseif($user['level'] == 8){ $exp = 20000;}
elseif($user['level'] == 9){ $exp = 25000;}
elseif($user['level'] == 10){ $exp = 50000;}
elseif($user['level'] == 11){ $exp = 75000;}
elseif($user['level'] == 12){ $exp = 100000;}
elseif($user['level'] == 13){ $exp = 125000;}
elseif($user['level'] == 14){ $exp = 175000;}
elseif($user['level'] == 15){ $exp = 225000;}
elseif($user['level'] == 16){ $exp = 275000;}
elseif($user['level'] == 17){ $exp = 325000;}
elseif($user['level'] == 18){ $exp = 375000;}
elseif($user['level'] == 19){ $exp = 450000;}
elseif($user['level'] == 20){ $exp = 525000;}
elseif($user['level'] == 21){ $exp = 600000;}
elseif($user['level'] == 22){ $exp = 675000;}
elseif($user['level'] == 23){ $exp = 750000;}
elseif($user['level'] == 24){ $exp = 850000;}
elseif($user['level'] == 25){ $exp = 950000;}
elseif($user['level'] == 26){ $exp = 1050000;}
elseif($user['level'] == 27){ $exp = 1150000;}
elseif($user['level'] == 28){ $exp = 1250000;}
elseif($user['level'] == 29){ $exp = 1400000;} //+150k
elseif($user['level'] == 30){ $exp = 1550000;}
elseif($user['level'] == 31){ $exp = 1700000;}
elseif($user['level'] == 32){ $exp = 1850000;}
elseif($user['level'] == 33){ $exp = 2000000;}
elseif($user['level'] == 34){ $exp = 2150000;} //+300k
elseif($user['level'] == 35){ $exp = 2450000;}
elseif($user['level'] == 36){ $exp = 2750000;}
elseif($user['level'] == 37){ $exp = 3050000;}
elseif($user['level'] == 38){ $exp = 3350000;}
elseif($user['level'] == 39){ $exp = 3900000;} //+500k
elseif($user['level'] == 40){ $exp = 4400000;}
elseif($user['level'] == 41){ $exp = 4900000;}
elseif($user['level'] == 42){ $exp = 5400000;}
elseif($user['level'] == 43){ $exp = 5900000;}
elseif($user['level'] == 44){ $exp = 7000000;}
elseif($user['level'] == 45){ $exp = 10000000;}
elseif($user['level'] == 46){ $exp = 15000000;}
elseif($user['level'] == 47){ $exp = 25000000;}
elseif($user['level'] == 48){ $exp = 40000000;}
elseif($user['level'] == 49){ $exp = 65000000;}
elseif($user['level'] >= 50){ $exp = 10000000000000000000000000000000000;}












$exp1 = ($exp);
$exp_progress = round(100/($exp1/$user['exp']));
if($exp_progress > 100) {$exp_progress = 100;}
$baks = (($user['level']+1)*5);

if($user['exp'] >= $exp1){
mysql_query("UPDATE `users` SET `exp` = '".($user['exp']- $exp1)."', `baks` = '".($user['baks'] + $baks)."', `level` = '".($user['level'] + 1)."' WHERE `id` = '".$user['id']."' LIMIT 1");
header('Location: ?');
$_SESSION['level'] = '<div class="ttl mmt green"><div class="tr"><div class="tc">Поздравляем!</div></div></div>
<div class="pb5"><span class="text_log succes"><b>Вы достигли '.($user['level']+1).' уровня!<br>Награда: <img class="price_img" src="/images/baks.png" alt="">'.$baks.' баксов</b></span></div>';  
exit();
}













if($ank['level'] == 1){ $ank_exp = 25;}
elseif($ank['level'] == 2){ $ank_exp = 250;}
elseif($ank['level'] == 3){ $ank_exp = 500;}
elseif($ank['level'] == 4){ $ank_exp = 1000;}
elseif($ank['level'] == 5){ $ank_exp = 2500;}
elseif($ank['level'] == 6){ $ank_exp = 5000;}
elseif($ank['level'] == 7){ $ank_exp = 10000;}
elseif($ank['level'] == 8){ $ank_exp = 20000;}
elseif($ank['level'] == 9){ $ank_exp = 25000;}
elseif($ank['level'] == 10){ $ank_exp = 50000;}
elseif($ank['level'] == 11){ $ank_exp = 75000;}
elseif($ank['level'] == 12){ $ank_exp = 100000;}
elseif($ank['level'] == 13){ $ank_exp = 125000;}
elseif($ank['level'] == 14){ $ank_exp = 175000;}
elseif($ank['level'] == 15){ $ank_exp = 225000;}
elseif($ank['level'] == 16){ $ank_exp = 275000;}
elseif($ank['level'] == 17){ $ank_exp = 325000;}
elseif($ank['level'] == 18){ $ank_exp = 375000;}
elseif($ank['level'] == 19){ $ank_exp = 450000;}
elseif($ank['level'] == 20){ $ank_exp = 525000;}
elseif($ank['level'] == 21){ $ank_exp = 600000;}
elseif($ank['level'] == 22){ $ank_exp = 675000;}
elseif($ank['level'] == 23){ $ank_exp = 750000;}
elseif($ank['level'] == 24){ $ank_exp = 850000;}
elseif($ank['level'] == 25){ $ank_exp = 950000;}
elseif($ank['level'] == 26){ $ank_exp = 1050000;}
elseif($ank['level'] == 27){ $ank_exp = 1150000;}
elseif($ank['level'] == 28){ $ank_exp = 1250000;}
elseif($ank['level'] == 29){ $ank_exp = 1400000;} //+150k
elseif($ank['level'] == 30){ $ank_exp = 1550000;}
elseif($ank['level'] == 31){ $ank_exp = 1700000;}
elseif($ank['level'] == 32){ $ank_exp = 1850000;}
elseif($ank['level'] == 33){ $ank_exp = 2000000;}
elseif($ank['level'] == 34){ $ank_exp = 2150000;} //+300k
elseif($ank['level'] == 35){ $ank_exp = 2450000;}
elseif($ank['level'] == 36){ $ank_exp = 2750000;}
elseif($ank['level'] == 37){ $ank_exp = 3050000;}
elseif($ank['level'] == 38){ $ank_exp = 3350000;}
elseif($ank['level'] == 39){ $ank_exp = 3900000;} //+500k
elseif($ank['level'] == 40){ $ank_exp = 4400000;}
elseif($ank['level'] == 41){ $ank_exp = 4900000;}
elseif($ank['level'] == 42){ $ank_exp = 5400000;}
elseif($ank['level'] == 43){ $ank_exp = 5900000;}
elseif($ank['level'] == 44){ $ank_exp = 7000000;}
elseif($ank['level'] == 45){ $ank_exp = 10000000;}
elseif($ank['level'] == 46){ $ank_exp = 15000000;}
elseif($ank['level'] == 47){ $ank_exp = 25000000;}
elseif($ank['level'] == 48){ $ank_exp = 40000000;}
elseif($ank['level'] == 49){ $ank_exp = 65000000;}
elseif($ank['level'] >= 50){ $ank_exp = 10000000000000000000000000000000000;}


?>