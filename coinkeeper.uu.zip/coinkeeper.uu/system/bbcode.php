<script src="/js/qbbcodes.js"></script>
<a class='panel' href="javascript:tag('[url=http://]', '[/url]')"><img src="/images/bb/l.png" alt="url" title="Ссылка"></a>
<a class='panel' href="javascript:tag('[b]', '[/b]')"><img src="/images/bb/b.png" alt="b" title="Жирный"></a>
<a class='panel' href="javascript:tag('[i]', '[/i]')"><img src="/images/bb/i.png" alt="i" title="Наклонный"></a>
<a class='panel' href="javascript:tag('[u]', '[/u]')"><img src="/images/bb/u.png" alt="u" title="Подчёркнутый"></a>
<a class='panel' href="javascript:tag('[s]', '[/s]')"><img src="/images/bb/s.png" alt="s" title="Перечёркнутый"></a>
<a class='panel' href="javascript:tag('[red]', '[/red]')"><img src="/images/bb/red.png" alt="s" title="Красный"></a>
 <a class='panel' href="javascript:tag('[blue]', '[/blue]')"><img src="/images/bb/blue.png" alt="s" title="Синий"></a>
 <a class='panel' href="javascript:tag('[green]', '[/green]')"><img src="/images/bb/green.png" alt="s" title="Зеленый"></a>
<a class='panel' href="javascript:tag('[cit]', '[/cit]')"><img src="/images/bb/q.png" alt="q" title="Цитата"></a><br>