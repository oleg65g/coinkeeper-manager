<?php
define ('dbhost', 'localhost');//сервер
define ('dbname', 'coinkeeper');//имя БД
define ('dbpass', 'coinkeeper');//пароль БД
define ('dbuser', 'coinkeeper');//Пользователь БД

/*
define ('dbhost', 'localhost');//сервер
define ('dbname', 'airbiz');//имя БД
define ('dbpass', 'airbiz');//пароль БД
define ('dbuser', 'airbiz');//Пользователь БД
*/

?>