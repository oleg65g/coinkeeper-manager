<?php
$id = abs(intval($_GET['id']));
$ank = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$id."'"));




$tikets = mysql_fetch_assoc(mysql_query("SELECT * FROM `tikets` WHERE `user`  = '".$user['id']."' "));
$tikets_msg = mysql_fetch_assoc(mysql_query("SELECT * FROM `tikets_msg` WHERE `user`  = '".$user['id']."' "));

////////////////// main //////////////////////
$cars_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `cars` WHERE `user` = "'.$user['id'].'" and `tip` = "1"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$presents_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `presents` WHERE `user` = "'.$user['id'].'" and `tip` = "1"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$clothes_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `clothes` WHERE `user` = "'.$user['id'].'" and `tip` = "1"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$restore_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `restore` WHERE `user` = "'.$user['id'].'" and `tip` = "1"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$rest_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `rest` WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0); //  

$science_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `science` WHERE `user` = "'.$user['id'].'" and `tip` = "1"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$sport_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `sport` WHERE `user` = "'.$user['id'].'" and `tip` = "1"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$service_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `service` WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY; '),0);

$products_col = mysql_result(mysql_query('SELECT COUNT(*) FROM `products` WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);
////////////////// main end  //////////////////////




///////////// basic ////////////////
$products = mysql_fetch_array(mysql_query('SELECT * FROM `products` WHERE `user` = "'.$user['id'].'"')); // продукты

$cars = mysql_fetch_array(mysql_query('SELECT * FROM `cars` WHERE `user` = "'.$user['id'].'"')); // продукты

$presents = mysql_fetch_array(mysql_query('SELECT * FROM `presents` WHERE `user` = "'.$user['id'].'" and `tip` = "1" ')); // продукты

$clothes = mysql_fetch_array(mysql_query('SELECT * FROM `clothes` WHERE `user` = "'.$user['id'].'" and `tip` = "1" ')); // продукты

$restore = mysql_fetch_array(mysql_query('SELECT * FROM `restore` WHERE `user` = "'.$user['id'].'" and `tip` = "1" ')); // продукты

$rest = mysql_fetch_array(mysql_query('SELECT * FROM `rest` WHERE `user` = "'.$user['id'].'" and `tip` = "1" ')); // продукты

$science = mysql_fetch_array(mysql_query('SELECT * FROM `science` WHERE `user` = "'.$user['id'].'" and `tip` = "1" ')); // продукты

$sport = mysql_fetch_array(mysql_query('SELECT * FROM `sport` WHERE `user` = "'.$user['id'].'" and `tip` = "1" ')); // продукты

$service = mysql_fetch_array(mysql_query('SELECT * FROM `service` WHERE `user` = "'.$user['id'].'" and `tip` = "1" ')); // продукты
///////////// basic end ////////////////




////////////////////////// scale////////////////////



$products_s = mysql_result(mysql_query('SELECT SUM(price) FROM products WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$cars_s = mysql_result(mysql_query('SELECT SUM(price) FROM cars WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$presents_s = mysql_result(mysql_query('SELECT SUM(price) FROM presents WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$restore_s = mysql_result(mysql_query('SELECT SUM(price) FROM restore WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$clothes_s = mysql_result(mysql_query('SELECT SUM(price) FROM clothes WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$rest_s = mysql_result(mysql_query('SELECT SUM(price) FROM rest WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$science_s = mysql_result(mysql_query('SELECT SUM(price) FROM science WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$sport_s = mysql_result(mysql_query('SELECT SUM(price) FROM sport WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$service_s = mysql_result(mysql_query('SELECT SUM(price) FROM service WHERE `user` = "'.$user['id'].'" and `tip` = "1" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$sums = ($products_s + $cars_s + $presents_s + $restore_s + $clothes_s + $rest_s + $science_s + $sport_s + $service_s);

//////////////////////////scale end////////////////////////


$company = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$id."'"));
################################################################################################

################################################################################################
$komnata = mysql_fetch_assoc(mysql_query("SELECT * FROM `tikets` WHERE `user`  = '".$user['id']."' "));
################################################################################################


################################################################################################
$komnata_pm = mysql_fetch_assoc(mysql_query("SELECT * FROM `pm_dialog` WHERE `user`  = '".$user['id']."' "));
$pm_msg = mysql_fetch_assoc(mysql_query("SELECT * FROM `pm_msg` WHERE `user`  = '".$user['id']."' "));
################################################################################################

///////////////////////
/////////////////
////////////
/////////////////////////////
/////////////////
////////////
/////////////////////////////
/////////////////
////////////
/////////////////////////////
/////////////////
////////////
/////


$cars_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `cars` WHERE `user` = "'.$user['id'].'" and `tip` = "2"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$presents_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `presents` WHERE `user` = "'.$user['id'].'" and `tip` = "2"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$clothes_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `clothes` WHERE `user` = "'.$user['id'].'" and `tip` = "2"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$restore_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `restore` WHERE `user` = "'.$user['id'].'" and `tip` = "2"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$rest_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `rest` WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0); //  

$science_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `science` WHERE `user` = "'.$user['id'].'" and `tip` = "2"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$sport_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `sport` WHERE `user` = "'.$user['id'].'" and `tip` = "2"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$service_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `service` WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY; '),0);

$products_col_in = mysql_result(mysql_query('SELECT COUNT(*) FROM `products` WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);
////////////////// main end  //////////////////////




///////////// basic ////////////////
$products_in = mysql_fetch_array(mysql_query('SELECT * FROM `products` WHERE `user` = "'.$user['id'].'" and `tip` = "2"')); // продукты

$cars_in = mysql_fetch_array(mysql_query('SELECT * FROM `cars` WHERE `user` = "'.$user['id'].'" and `tip` = "2"')); // продукты

$presents_in = mysql_fetch_array(mysql_query('SELECT * FROM `presents` WHERE `user` = "'.$user['id'].'" and `tip` = "2" ')); // продукты

$clothes_in = mysql_fetch_array(mysql_query('SELECT * FROM `clothes` WHERE `user` = "'.$user['id'].'" and `tip` = "2" ')); // продукты

$restore_in = mysql_fetch_array(mysql_query('SELECT * FROM `restore` WHERE `user` = "'.$user['id'].'" and `tip` = "2" ')); // продукты

$rest_in = mysql_fetch_array(mysql_query('SELECT * FROM `rest` WHERE `user` = "'.$user['id'].'" and `tip` = "2" ')); // продукты

$science_in = mysql_fetch_array(mysql_query('SELECT * FROM `science` WHERE `user` = "'.$user['id'].'" and `tip` = "2" ')); // продукты

$sport_in = mysql_fetch_array(mysql_query('SELECT * FROM `sport` WHERE `user` = "'.$user['id'].'" and `tip` = "2" ')); // продукты

$service_in = mysql_fetch_array(mysql_query('SELECT * FROM `service` WHERE `user` = "'.$user['id'].'" and `tip` = "2" ')); // продукты
///////////// basic end ////////////////





////////////////////////// scale////////////////////



$products_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM products WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$cars_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM cars WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$presents_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM presents WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$restore_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM restore WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$clothes_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM clothes WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$rest_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM rest WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$science_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM science WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$sport_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM sport WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$service_s_in = mysql_result(mysql_query('SELECT SUM(price) FROM service WHERE `user` = "'.$user['id'].'" and `tip` = "2" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$sums_in = ($products_s_in + $cars_s_in + $presents_s_in + $restore_s_in + $clothes_s_in + $rest_s_in + $science_s_in + $sport_s_in + $service_s_in);



################################################################################################
################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################


$cars_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `cars` WHERE `user` = "'.$user['id'].'" and `tip` = "3"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$presents_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `presents` WHERE `user` = "'.$user['id'].'" and `tip` = "3"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$clothes_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `clothes` WHERE `user` = "'.$user['id'].'" and `tip` = "3"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$restore_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `restore` WHERE `user` = "'.$user['id'].'" and `tip` = "3"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$rest_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `rest` WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0); //  

$science_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `science` WHERE `user` = "'.$user['id'].'" and `tip` = "3"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$sport_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `sport` WHERE `user` = "'.$user['id'].'" and `tip` = "3"and `time` < NOW() - INTERVAL 30 DAY; '),0); //  

$service_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `service` WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY; '),0);

$products_col_p = mysql_result(mysql_query('SELECT COUNT(*) FROM `products` WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);
////////////////// main end  //////////////////////




///////////// basic ////////////////
$products_p = mysql_fetch_array(mysql_query('SELECT * FROM `products` WHERE `user` = "'.$user['id'].'"')); // продукты

$cars_p = mysql_fetch_array(mysql_query('SELECT * FROM `cars` WHERE `user` = "'.$user['id'].'"')); // продукты

$presents_p = mysql_fetch_array(mysql_query('SELECT * FROM `presents` WHERE `user` = "'.$user['id'].'" and `tip` = "3" ')); // продукты

$clothes_p = mysql_fetch_array(mysql_query('SELECT * FROM `clothes` WHERE `user` = "'.$user['id'].'" and `tip` = "3" ')); // продукты

$restore_p = mysql_fetch_array(mysql_query('SELECT * FROM `restore` WHERE `user` = "'.$user['id'].'" and `tip` = "3" ')); // продукты

$rest_p = mysql_fetch_array(mysql_query('SELECT * FROM `rest` WHERE `user` = "'.$user['id'].'" and `tip` = "3" ')); // продукты

$science_p = mysql_fetch_array(mysql_query('SELECT * FROM `science` WHERE `user` = "'.$user['id'].'" and `tip` = "3" ')); // продукты

$sport_p = mysql_fetch_array(mysql_query('SELECT * FROM `sport` WHERE `user` = "'.$user['id'].'" and `tip` = "3" ')); // продукты

$service_p = mysql_fetch_array(mysql_query('SELECT * FROM `service` WHERE `user` = "'.$user['id'].'" and `tip` = "3" ')); // продукты
///////////// plans end ////////////////







////////////////////////// scale////////////////////

$products_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM products WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$cars_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM cars WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$presents_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM presents WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$restore_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM restore WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$clothes_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM clothes WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$rest_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM rest WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$science_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM science WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$sport_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM sport WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);

$service_s_p = mysql_result(mysql_query('SELECT SUM(price) FROM service WHERE `user` = "'.$user['id'].'" and `tip` = "3" and `time` < NOW() - INTERVAL 30 DAY;'),0);


$sums_p = ($products_s_p + $cars_s_p + $presents_s_p + $restore_s_p + $clothes_s_p + $rest_s_p + $science_s_p + $sport_s_p + $service_s_p);


//mysql_query("INSERT INTO `products` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '10000',`col` = '1',`tip` = '3'");
//
//mysql_query("INSERT INTO `clothes` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '3000',`col` = '1',`tip` = '3'");
//
//mysql_query("INSERT INTO `restore` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '2000',`col` = '1',`tip` = '3'");
//
//
//mysql_query("INSERT INTO `sport` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '2000',`col` = '1',`tip` = '3'");
//
//mysql_query("INSERT INTO `rest` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '1000',`col` = '1',`tip` = '3'");
//
//mysql_query("INSERT INTO `science` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '2000',`col` = '1',`tip` = '3'");
//
//mysql_query("INSERT INTO `cars` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '2000',`col` = '1',`tip` = '3'");
//
//mysql_query("INSERT INTO `presents` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '2000',`col` = '1',`tip` = '3'");
//
//mysql_query("INSERT INTO `service` SET `user` = '".$user['id']."', `name` = 'тест', `time` = '".time()."',`price` = '2000',`col` = '1',`tip` = '3'");

?>