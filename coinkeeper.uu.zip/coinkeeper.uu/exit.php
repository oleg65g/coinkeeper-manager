<?php

//-----Подключаем функции-----//
require_once ('system/function.php');
require_once ('system/header.php');
//-----Переадресация для не зарегистрированных-----//
$title = 'Выход';
if(!$user['id']){
header('Location: /');
exit();
}




if(isset($_REQUEST['okda'])){
setcookie('uslog', '', time() - 86400*31);
setcookie('uspass', '', time() - 86400*31);
mysql_close($mysql_connect);
header('location: /');
}
if(isset($_REQUEST['no'])){
if($user['start'] == 0){
header('location: /');
}else{
header('location: '.$HOME.'start/'.$user['start'].'/');
}
}


if(isset($_GET['ex'])){
$_SESSION['ses'] = '<span class="orange_dark2">Выйти?</span><br>
<hr>
<a href="'.$HOME.'exit?okda" class="btn" style="min-width: 110px;">
<span class="br"><span class="bc plr5"><img class="price_img" src="/images/ok.png"> Подтверждаю</span></span></a>
<a href="'.$HOME.'settings/" class="btn" style="min-width: 110px;">
<span class="br"><span class="bc plr5"><img class="price_img" src="/images/err.png"> Отмена</span></span></a>';
header('Location: ?');
exit();
}    
    







require_once ('system/footer.php');
?>