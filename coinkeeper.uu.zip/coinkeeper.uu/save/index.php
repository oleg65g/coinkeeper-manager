<?php
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']){
header('Location: /');
exit();
}

if($user['login'] == 'Гость'){





echo '<div class="start mar6t">

	<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">Сохранение</div></div></div>




		<div class="msg mrg_msg1 mt10 c_brown4">
		<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">
								<form action="" method="POST">
					<div class="mb3">Логин</div>
					<input class="login_input mb10" type="text" name="login" value=""><br>
					<div class="mb3">Пароль</div>
					<input class="login_input mb10" type="text" name="pass" value=""><br>


					
					<div class="bbtn_sm mt3"><div class="br">
						<input type="submit" name="reg" value="Сохранить">
					</div></div>
					
				</form>
						</div></div></div></div></div>
	</div>
</div>';




//-----Если жмут submit(кнопку)-----//
if(isset($_REQUEST['reg'])){

$login = strong($_POST['login']);
$pass = strong($_POST['pass']);
$sex = strong($_POST['sex']);
$email = strong($_POST['email']);

if(empty($login)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Логин" обязательно для ввода.';
exit();
}
if(empty($pass)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Пароль" обязательно для ввода.';
exit();
}
if(!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $login)){
header('Location: ?');
$_SESSION['err'] = 'Запрещённые символы в поле "Логин".<br>
Логин может состоять из букв русского или английского алфавитов, и цифр.
';
exit();
}
if(!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $pass)){
header('Location: ?');
$_SESSION['err'] = 'Запрещенные символы в поле "Пароль".';
exit();
}
if(mysql_result(mysql_query("SELECT COUNT(*)  FROM `users` WHERE `login` = ".$login.""),0) == true){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Такой "Логин" уже существует.</font>';
exit();
}
$sql1 = mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `login` = '".$login."'"); 
if(mysql_result($sql1, 0) > 0){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Такой "Логин" уже существует.</font>';
exit();
}

/*
if(empty($email)){
header('Location: ?');
$_SESSION['err'] = 'Поле "e-mail" обязательно для ввода.';
exit();
}
if (!preg_match('/[0-9a-z_\-]+@[0-9a-z_\-^\.]+\.[a-z]{2,6}/i', $email)) {
header('Location: ?');
$_SESSION['err'] = '<font color=red>Формат "e-mail" введён не верно.</font>';
exit();
}
$sqlemail = mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `email` = '".$email."'"); 
if (mysql_result($sqlemail, 0) > 0) {
header('Location: ?');
$_SESSION['err'] = '<font color=red>Такой "e-mail" уже существует.</font>';
exit();
}

`email` = '".($user['email']=$email)."'
*/


mysql_query("UPDATE `users` SET `passw` = '".$pass."', `baks` = '".($user['baks']+100)."', `login` = '".($user['login']=$login)."', `pass` = '".($user['pass']=md5(md5(md5($pass))))."' WHERE `id` = '".$user['id']."' LIMIT 1");
mysql_query("UPDATE `user_avatars` SET `sex` = '".$sex."' WHERE `user` = '".$user['id']."' LIMIT 1");

setcookie('uslog', $login, time()+86400*31, '/');
setcookie('uspass', md5(md5(md5($pass))), time()+86400*31, '/');
$_SESSION['ok'] = 'Вы успешно сохранили свой аккаунт!<hr>
Ваш логин: <font color=black>'.$login.'</font><hr>
Ваш пароль: <font color=black>'.$pass.'</font>';
header('Location: '.$HOME.'');
exit();
}


}else{
header('Location: '.$HOME.'');
exit();
}
echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';
require_once ('../system/footer.php');
?> 