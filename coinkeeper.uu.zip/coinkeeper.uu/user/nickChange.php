<?php
$title = 'Смена ника';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: /');
exit();
}



if (isset($_POST['submit'],$_POST['login'])){
$login = strong($_POST['login']);
$sql1 = mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `login` = '".$login."'"); 

    

if(empty($login)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Логин" обязательно для ввода.';
exit();
}
if(mysql_result($sql1, 0)){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Такой ник уже существует.</font>';
exit();
}
if(mysql_result(mysql_query("SELECT COUNT(*)  FROM `users` WHERE `login` = ".$login.""),0) == true){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Такой ник уже существует.</font>';
exit();
}
if(mb_strlen($login) > 30 or mb_strlen($login) < 5){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Минимум 5 Максимум 30 символов.</font>';
exit();
}
if( !preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $login)){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Ошибка символов</font>';
exit();
}

mysql_query("UPDATE `users` SET `login` = '".$login."'
WHERE `id` = '". $user['id'] ."' LIMIT 1");

    

setcookie('uslog', $login, time()+86400*31, '/');
header('Location: ?');
$_SESSION['ok'] = 'Настройки успешно изменены!<hr><font color=red>Новый логин для входа: '.$login.'</font>';
exit();
}













//echo'<div class="msg mrg_msg1 mt10 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="darkgreen_link">
//
//
//<div class="bordered">
//<div class="mt4 center">';
//
//
//echo'
//
//
//</div></div></div></div></div></div></div></div>
//';



echo'<div class="msg mrg_msg1 mt10 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="darkgreen_link">


<div class="bordered">
<div class="mt4 center">



<center><form action="" method="POST">
Новый логин:<br> <input type="text" style="width: 95%;" name="login" value="'.$user['login'].'" maxlength="15" > 



				<div class="bbtn_sm mt5"><div class="br">
					<input type="submit" name="submit" value="Сменить логин">
				</div></div>
</span> 
</div>
';


echo'</div></div></div></div></div></div></div>
';








echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'settings/" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';



require_once ('../system/footer.php');
?>