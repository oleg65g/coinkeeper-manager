<?php
$title = 'Настройки';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: /');
exit();
}

echo'<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">Настройки</div></div></div>';





echo '<div class="marea mt5"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">';



echo '<div class="mbtn orange"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'nickchange/" class="mb_ttl ok">Смена логина</a></div></div></div>';
echo '<div class="mbtn orange"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'passchange/" class="mb_ttl ok">Смена пароля</a></div></div></div>';

//echo '<div class="mbtn orange"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'settemail/" class="mb_ttl ok">Смена почты</a></div></div></div>';

echo '<div class="mbtn orange"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'exit/?ex" class="mb_ttl error"><font color = red>Выйти</font></a></div></div></div>';



echo '</div></div></div></div></div></div>';

echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';


require_once ('../system/footer.php');
?>