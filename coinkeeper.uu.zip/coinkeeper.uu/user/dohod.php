<?php
$title = 'Мои самолёты';
//-----Подключаем функции-----//
require_once ('../system/function.php');
//-----Подключаем вверх-----//
require_once ('../system/header.php');
//-----Если гость,то...----//
if(!$user['id']) {
header('Location: /');
exit();
}










    
echo'<div class="marea mt5 dbmenu"><div class="bmenu">
<table class="tbmenu"><tbody><tr><td class="va-t ">

<span class="wbmenu"><a href="'.$HOME.'">
<span class="ttl-m green"><span class="tr"><span class="tc"><font size=1>Расходы</font></span></span></span></a></span></td><td class="va-t "><span class="wbmenu">

<span class="wbmenu"><a href="'.$HOME.'dohod/">
<span class="ttl-m green"><span class="tr"><span class="tc"><font color=grey size=1>Доходы</font></span></span></span></a></span></td><td class="va-t "><span class="wbmenu">

<a href="'.$HOME.'plans/">
<span class="ttl-m green"><span class="tr"><span class="tc"><font size=1>В планах</font></span></span></span></a></span></td></tr></tbody>

</table>
</div></div>';
    
    
    
/////////////////////////////

    
echo '<div class="start mar6t">
<div class="msg mrg_msg1 mt10 c_brown4">
<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">';
							
                            
                            

echo '<div class="dbmenu"><div class="apanel">';
echo '<table class="tbmenu"><tbody><tr>';

echo '<td><span class="slot"><span class="attl">Продукты</span>';
echo '<a href="'.$HOME.'products_in/" class="abtn"><img src="/images/prod.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$products_col_in.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Одежда</span>';
echo '<a href="'.$HOME.'clothes_in/" class="abtn"><img src="/images/clot.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$clothes_col_in.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Рестораны</span>';
echo '<a href="'.$HOME.'restore_in/" class="abtn"><img src="/images/restore.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$restore_col_in.'</span></span>
</span></td>';

echo '</tr>
</tbody></table></div></div><br>';
/////

echo '<div class="dbmenu"><div class="apanel">';
echo '<table class="tbmenu"><tbody><tr>';

echo '<td><span class="slot"><span class="attl">Здоровье</span>';
echo '<a href="'.$HOME.'sport_in/" class="abtn"><img src="/images/aid.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$sport_col_in.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Развлечения</span>';
echo '<a href="'.$HOME.'rest_in/" class="abtn"><img src="/images/rest.png" width="48" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$rest_col_in.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Образование</span>';
echo '<a href="'.$HOME.'science_in/" class="abtn"><img src="/images/sci.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$science_col_in.'</span></span>
</span></td>';

echo '</tr>
</tbody></table></div></div><br>';

///////
    

echo '<div class="dbmenu"><div class="apanel">';
echo '<table class="tbmenu"><tbody><tr>';

echo '<td><span class="slot"><span class="attl">Транспорт</span>';
echo '<a href="'.$HOME.'cars_in/" class="abtn"><img src="/images/cars.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$cars_col_in.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Подарки</span>';
echo '<a href="'.$HOME.'presents_in/" class="abtn"><img src="/images/presents.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$presents_col_in.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Сервисы</span>';
echo '<a href="'.$HOME.'service_in/" class="abtn"><img src="/images/ser.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$service_col_in.'</span></span>
</span></td>';

echo '</tr>
</tbody></table></div></div><br>';                      
                            
                            
                         
echo'</div></div></div></div></div></div>
</div>';    


//////scale

$cscale1 = round((($products_s_in*100)/$sums_in));
if($cscale1 > 100) {$cscale1 = 100;}  

    
$cscale2 = round((($cars_s_in*100)/$sums_in));
if($cscale2 > 100) {$cscale2 = 100;}  
    
    
$cscale3 = round((($presents_s_in*100)/$sums_in));
if($cscale3 > 100) {$cscale3 = 100;}  
    
    
$cscale4 = round((($restore_s_in*100)/$sums_in));
if($cscale4 > 100) {$cscale4 = 100;}  
    
    
$cscale5 = round((($clothes_s_in*100)/$sums_in));
if($cscale5 > 100) {$cscale5 = 100;}  
    
    
$cscale6 = round((($rest_s_in*100)/$sums_in));
if($cscale6 > 100) {$cscale6 = 100;}  
    
    
$cscale7 = round((($science_s_in*100)/$sums_in));
if($cscale7 > 100) {$cscale7 = 100;}  
    
    
$cscale8 = round((($sport_s_in*100)/$sums_in));
if($cscale8 > 100) {$cscale8 = 100;}  
    
    
$cscale9 = round((($service_s_in*100)/$sums_in));
if($cscale9 > 100) {$cscale9 = 100;}  

$sums_in = ($products_s_in + $cars_s_in + $presents_s_in + $restore_s_in + $clothes_s_in + $rest_s_in + $science_s_in + $sport_s_in + $service_s_in);    


$money_look = $products_s_in/1000;     
$money_look2 = $cars_s_in/1000; 
$money_look3 = $presents_s_in/1000; 
$money_look4 = $restore_s_in/1000; 
$money_look5 = $clothes_s_in/1000; 
$money_look6 = $rest_s_in/1000; 
$money_look7 = $science_s_in/1000;         
$money_look8 = $sport_s_in/1000; 
$money_look9 = $service_s_in/1000; 
    
  
    
echo '<br><div class="msg mrg_msg3 mt9 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">





<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale1.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale1.'%</td> 
            
                      
Продукты






	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look5.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale5.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale5.'%</td>
          <hr color = #e6a837 size = 1px>           
Одежда   
          
            
            
            
            
            
            
            
            	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look4.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale4.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale4.'%</td>
            
  <hr color = #e6a837 size = 1px>                       
Рестораны 









            	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look8.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale8.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale8.'%</td>
  <hr color = #e6a837 size = 1px>                    
Здоровье



            	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look6.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale6.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale6.'%</td>
            
  <hr color = #e6a837 size = 1px>                     
Развлечения
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look7.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale7.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale7.'%</td>
  <hr color = #e6a837 size = 1px>              
Образование
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look2.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale2.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale2.'%</td>
            
  <hr color = #e6a837 size = 1px>             
Транспорт            
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look3.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale3.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale3.'%</td>
    <hr color = #e6a837 size = 1px>                     
Подарки
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ico16-up.png" height="16" width="16" alt="">'.$money_look9.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale9.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale9.'%</td>
            
  <hr color = #e6a837 size = 1px>           
Сервисы
                       
       





		</tr></tbody></table>
</span></div></div></div></div></div></div>'; // прогресс уровня      
    
    





require_once ('../system/footer.php');
?>