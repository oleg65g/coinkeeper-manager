<?php
$title = 'Рейтинг по опыту';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']){
header('Location: /');
exit();
}

echo '<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">Продукты</div></div></div>';

//////////////////////////////////




if($service){

if (empty($user['max'])) $user['max']=20;
$max = 10;
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `service` WHERE `user` = '".$user['id']."' and `tip` = '1'"),0);
$k_page = k_page($k_post,$max);
$page = page($k_page);
$start = $max*$page-$max;
$k_post = $start+1;
$tanks_rating = mysql_query("SELECT * FROM `service` WHERE `user` = '".$user['id']."' and `tip` = '1'  ORDER BY `price` DESC LIMIT $start,$max");
echo '<div class="msg mrg_msg1 mt5 c_brown4"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 omin_medals">';
while($a = mysql_fetch_assoc($tanks_rating)){
$number = $k_post++;      
echo '<div class="mb10"><div><div style="margin-top: 4px;">
<div><span class="fl"><span>'.$number.'</span>. <span><span class="nobr"><span class="nobr"><b>'.($a['name']).':</b>

<a class="c_gray">('.$a['col'].' кол)</a>';

echo'

<img src="/images/coin.png" class="price_img">'.$miss['coin'].''.$a['price'].' грн
';  



echo'</span></span></span> </span>
<span class="fr">
'.vremja($a['time']).'
</span></div>';
    
 
   echo' <a class="c_gray" href="'.$HOME.'redact_service/'.$a['id'].'">Ред.</a></a> '; 
echo'<div class="cb"></div><div class="cb"></div></div></div></div>
<hr>';


}
}
echo '</div></div></div></div></div></div>';
if ($k_page > 1) {
echo str(''.$HOME.'service/?',$k_page,$page); // Вывод страниц
}

///////////











echo'</div></div></div></div></div></div></div>
';



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if(isset($_REQUEST['addadmin'])) {

    
$msga2 = ($_POST['name']);
$msga_name = ($_POST['price']);
$cc = ($_POST['col']);

if(empty($msga2)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Название" обязательно для ввода.';
exit();
}
    
if(empty($msga_name)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Цена" обязательно для ввода.';
exit();
}        
    
if(empty($cc)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Количество" обязательно для ввода.';
exit();
}    
mysql_query("INSERT INTO `service` SET `user` = '".$user['id']."', `name` = '".$msga2."', `time` = '".time()."',`price` = '".$msga_name."',`col` = '".$cc."',`tip` = '1'");


$_SESSION['ses'] = 'Операция прошла успешно!';     
header('Location: ?');
exit();
}

    
echo '<div class="msg mlr5 mt10 c_brown4">
<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 left p10">';
echo '<center><form action="" method="POST">
Название:<br> <input type="text" style="width: 95%;" name="name" value="" maxlength="25" > 

Цена:<br> <input type="text" style="width: 95%;" name="price" value="" maxlength="7" > 

Количество:<br> <input type="text" style="width: 95%;" name="col" value="" maxlength="7" > 

<div class="bbtn_sm mt5"><div class="br">
					<input type="submit" name="addadmin" value="Добавить">
				</div></div>';

echo '</span></li></ul>';

echo'</div></div></div></div></div></div></div>'; 

    






echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';


require_once ('../system/footer.php');
?>