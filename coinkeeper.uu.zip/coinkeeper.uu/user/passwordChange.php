<?php
$title = 'Смена пароля';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: /');
exit();
}

echo'<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">'.$title.'</div></div></div>';

// функция 
function make_password($num_chars){
if ((is_numeric($num_chars)) &&  
($num_chars > 0) && (!is_null($num_chars))){ 
$password = ""; 
$accepted_chars="abcGdefghHiFXZBVNPERRGjklmnUopqGGFGrstHuvwKxyzl234567890"; 
if (necessary.srand(((int)((double)microtime()*100000000000003)))); 
for ($i= 0; $i < $num_chars; $i++){ 
$random_number = rand(0, (strlen($accepted_chars)-1)); $password .= $accepted_chars[$random_number]; 
} 
return $password; 
} 
} 
$dlina=12; //количество символов в пароле 

$newpass = make_password($dlina); 



if(isset($_REQUEST['retpass'])){
$p = strong($_POST['p']);
$np = strong($_POST['np']);

if(empty($p)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Пароль" обязательно для ввода.';
exit();
}
if(empty($np)){
header('Location: ?');
$_SESSION['err'] = 'Поле "Повтор пароля" обязательно для ввода.';
exit();
}
if($np!=$p){
header('Location: ?');
$_SESSION['err'] = 'Ошибка! Пароли не совпадают.';
exit();
}
if(mb_strlen($p) < 8){
header('Location: ?');
$_SESSION['err'] = 'Ошибка! Введите пароль больше 8 символов.';
exit();
}
if(mb_strlen($np) < 8){
header('Location: ?');
$_SESSION['err'] = 'Ошибка! Введите пароль больше 8 символов.';
exit();
}
if( !preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $np)){
header('Location: ?');
$_SESSION['err'] = 'Ошибка символов.';
exit();
}
if( !preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $p)){
header('Location: ?');
$_SESSION['err'] = 'Ошибка символов.';
exit();
}

mysql_query("UPDATE `users` SET `pass` = '".md5(md5(md5($np)))."' WHERE `id` = '".$user['id']."'");
setcookie('uspass', md5(md5(md5($np))), time()+86400*31, '/');
header('Location: ?');
$_SESSION['ok'] = 'Настройки успешно изменены!<hr><font color=red>Новый пароль для входа:</font> <font color=black>'.$np.'</font>';
exit();
}



echo'<div class="msg mrg_msg1 mt10 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="darkgreen_link">';


//форма//
echo '<div class="bordered mt4"><center>
<form method="POST" action="?">
Пароль:<br><input placeholder="Введите Пароль" type="password" name="p" style="width: 95%;" maxlength="30" value=""><br>
Еще раз:<br><input placeholder="Повторите Ввод" type="password" name="np" style="width: 95%;" maxlength="30" value=""><br>

<a class="btni" style="" href="?"><img style="vertical-align: 30%" src="/images/refresh.png" width="20"></a>
				<div class="bbtn_sm mt5"><div class="br">
					<input type="submit" name="retpass" value="Сменить пароль">
				</div></div></div>';


echo '<div class="minor center"><span>Рекомендуемый пароль: <span class=" tred"><font color=black>'.$newpass.'</font></span></span> </div></div></div></div></div></div></div>';



echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'settings/" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';





require_once ('../system/footer.php');
?>