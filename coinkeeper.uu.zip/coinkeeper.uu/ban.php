<?php

require_once ('system/function.php');



?>
<script src="<?=$HOME?>js/jquery.js"></script>
<script src="<?=$HOME?>js/bootstrap-collapse.js"></script>
<script src="<?=$HOME?>js/bootstrap.min.js"></script>
<script src="<?=$HOME?>js/bootstrap-alert.js"></script>
<link rel="stylesheet" href="<?=$HOME?>diz.css">
<?php
$sql = mysql_fetch_assoc(mysql_query("SELECT * FROM `settings` WHERE `id` = '1'"));
echo '<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE">
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
<meta name="Keywords" content="'.$sql['key'].'" />
<meta name="Description" content="'.$sql['des'].'" />
<meta name="copyright" content="'.$sql['cop'].'" />
<link rel="/images/game.png" href="/images/game.png">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico">
<link rel="stylesheet" type="text/css" href="/diz.css">
<title>'.$title.'</title>
</head>';


$t = microtime(1);
require_once ('system/taimers.php');
        
        


//
//echo '<table style="width:100%;" cellspacing="0" cellpadding="0"><tbody><tr><td style="padding:0 1px 0 0;">';
//
//echo '<a class="btnl" style="background-color:#2b577f;" href="/"><img class="fl" width="36" height="36" alt="обн" src="/images/header/arrow_left_white2.png">';
//
//
//echo '<img src="/images/header/money_36.png" class="fr" width="36" height="36" alt="$">
//<div class="fr" style="margin-right: 4px; text-align:right;">
//<div style="padding-top: 4px; line-height: 1em;color:#FFFFFF;" id="id2">
//'.n_f($user['money']).'</div><div class="small" style="line-height: 0.8em; color: #FFCF54;">';
//
//
//if($user['money'] == 1){
//echo '<span>1</span>';
//}else{
//echo '<span>'.n_f($dohod).'</span>';
//}
//echo ' в сек</div></div><div class="cb"></div></a>';






//$mes = mysql_result(mysql_query("SELECT COUNT(id) FROM `message` WHERE `komy` = '".$user['id']."' and `readlen` = '0'"),0);
//
//if($mes != 0) {
//echo '</td><td style="width: 52px;"><a class="btnl" style="background-color:#2b577f;" id="id3" href="'.$HOME.'mes/"><img src="/images/header/mail_new.png" alt="почта" width="36" height="36" class="fr"><div class="cb"></div></a></td></tr></tbody></table>';
//}else{
//echo '</td><td style="width: 52px;"><a class="btnl" style="background-color:#2b577f;" id="id3" href="'.$HOME.'mes/"><img src="/images/header/mail_white.png" alt="почта" width="36" height="36" class="fr"><div class="cb"></div></a></td></tr></tbody></table>';
//}






if (isset($_SESSION['err'])){
?>
<div class="feedback"><ul class="feedbackPanel"><li class="feedbackPanelERROR"><span class="feedbackPanelERROR"><?=$_SESSION['err']?></span></li>
</ul></div>
<?php
unset($_SESSION['err']);
}






















// 127.0.0.1
// 95.213.218.31  -  чих-пых
// 31.173.101.75  -  mmars pro
if($user['ip'] == '95.213.218.31' && $user['ip'] == '31.173.101.75') {
$title = 'Доступ Ограничен';

echo '<div class="feedback"><ul class="feedbackPanel"><li class="feedbackPanelERROR"><span class="feedbackPanelERROR">
<font size=3 color=red>Из-за многократных нарушений, Вам закрыли доступ в игру!</font>
</span></li></ul></div>
<div class="bordered mt4" style="padding: 0 4px 4px 0;"><center>';







echo 'Причина: неоднократные нарушения<br>
Кто: '.nick(1).' <br>
Закончится: Пожизнено <br>';

echo '</center></div>';
echo '<a class="btnl mt4" href="?"><img src="/images/refresh_white2.png" width="24" height="24" alt="" title=""> Обновить</a>';
















}else{









echo '<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc"><font size=3 color=red>Ваш аккаунт заблокирован!</font></div></div></div>';
$ban = mysql_fetch_array(mysql_query('SELECT * FROM `ban` WHERE `user` = "'.$user['id'].'"'));
if($ban['time_end'] < time()){
mysql_query("UPDATE `users` SET `colors`='' WHERE `id` = '".$user['id']."' limit 1");
mysql_query('DELETE FROM `ban` WHERE `user` = '.$user['id'].' ');
header ('Location: '.$HOME.'');
exit();
}

    

echo '<div class="msg mrg_msg1 mt10 c_brown4">
<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
<div class="left font_14 pet_profile_stat">';
echo '<div class="stat_item">Кто:'.nick($user['id']).'</div>';











echo '<div class="stat_item"><src="/images/exp.png"> Причина: '.$ban['prich'].' </div>';

echo '<div class="stat_item"><src="/images/coin.png">  Закончится:<img class="price_img" src="/images/clock.png"> '._time($ban['time_end']-time()).'</div>';

echo '</div></div></div></div></div></div></div>';
    


                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                                
								
		echo'</div>
	</div></div></div></div></div>
</div>'; 


}








require_once ('system/footer.php');
?> 