<?php
$title = 'Регистрация';
require_once ('system/function.php');
require_once ('system/header.php');
if($user['id']) {
header('Location: /');
exit();
}


/*
if($_SERVER['REMOTE_ADDR'] != '130.180.212.167'){
$mult = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `ip` = '".strong($_SERVER['REMOTE_ADDR'])."' "),0);
if($mult >= 1){
header('Location: '.$HOME.' ');
$_SESSION['err'] = '<FONT COLOR=RED>Нарушениме правил соглашения!<br> Пункт: 2.6 ЗАПРЕЩАЕТСЯ Создавать дополнительные аккаунты.</FONT>';
exit();
}
}
*/
$sex = rand(1,2);
$pass = rand(1000000000,9000000000);
$viz = time()+1800;
$login = 'Гость';
mysql_query("INSERT INTO `users` SET `login` = 'Гость', `pass` = '".md5(md5(md5($pass)))."', `sex` = '".$sex."', `datareg` = '".time()."',`level` = '1', `viz` = '".$viz."', `last_update` = '".time()."' ");
//-----Вычесляем id-----//
//$uid = mysql_insert_id();
//mysql_query("INSERT INTO `user_biznes_1` SET `name` = 'Космопорт', `images` = '1', `dohod` = '1',`cena` = '1', `biznes_dohod` = '1', `user` = '".$uid."', `id_room` = '1' ");

echo '<div class="main">
<div class="ovh" style="padding-top: -1px;"></div>
<div class="content">
<div class="start"><div class="msg mrg_msg1 mt10 c_brown4"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">
<img src="/images/logo.jpg" alt="" style="width:100%; border-radius: 8px;">';


$inv = mysql_fetch_assoc(mysql_query("SELECT id,login from `users` where `id` = '".abs(intval($_GET['inv']))."'"));

if(isset($_GET['inv'])){
$inv = mysql_fetch_assoc(mysql_query("SELECT id,login from `users` where `id` = '".abs(intval($_GET['inv']))."'"));
if(!empty($inv['id'])){
echo '<div class="content">Вы регистрируйтесь по приглашению игрока <b>'.$inv['login'].'</b>
<br>Бонус за регистрацию <span class="nowrap"><img class="price_img" src="/images/coin.png">100</span></span> монет!</div>';
}
}


echo '<div class="mb10"><a href="'.$HOME.'autolog.php?ulog='.$login.'&amp;upas='.$pass.'" class="bbtn mt5 mb5" style="width: 200px"><span class="br"><span class="bc">Продолжить</span></span></a>
</div></div></div></div></div></div></div>


<div class="msg mrg_msg1 mt5 c_brown4"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">

<div class=left><b>Авиа Бизнесмены</b> - это совершенно новая и увлекательная многопользовательская Экономическая бизнес игра.
<br>
<div class="mrg_msg1 mt5 c_blueq">В игре Вам предстоит управлять своей компанией, улучшать и продвигать ее соревнуясь с другими игроками.</div>
<div class="mrg_msg1 mt5 c_blueq">Для начала развития, у Вас будет стартовый капитал, за который Вы сможете построить себе не большой Бизнес.</div>
</div>
Дальнейшее развитие зависит только от Вас!
</div></div></div></div></div></div></div></div></div>';

















?>