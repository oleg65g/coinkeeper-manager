<?php
require_once ('../system/function.php');
$title = 'Новости';
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: '.$HOME.'');
exit();
}

if(!$user['id']) {
header('Location: /');
exit();
}




$id = abs(intval($_GET['id']));
$name_t = mysql_fetch_assoc(mysql_query("SELECT * FROM `restore` WHERE `id` = '".$id."'"));
if($name_t == 0){
header('Location: /');
$_SESSION['err'] = 'Запись не найдена.';
exit();
}


  
echo '<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">Редактирование записи</div></div></div>';

if(isset($_REQUEST['addadmin'])) {

$msga_name = ($_POST['name']);
$coll = ($_POST['col']);
$pricee = ($_POST['price']);    
    
mysql_query("UPDATE `restore` SET `name` = '".($name_t['name']= $msga_name)."',`col` = '".($name_t['col']= $coll)."',`price` = '".($name_t['price']= $pricee)."',`time` = '".time()."' WHERE `id` = '".$id."' LIMIT 1");
     
$_SESSION['ses'] = 'Операция прошла успешно!';   
header('Location: '.$HOME.'restore_in/');
exit();
}


echo '<div class="msg mlr5 mt10 c_brown4">
<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 left p10">';
echo '<center><form action="" method="POST">
Название:<br> <input type="text" style="width: 95%;" name="name" value='.$name_t['name'].' maxlength="25" > 

Цена:<br> <input type="text" style="width: 95%;" name="price" value="" maxlength="7" > 

Количество:<br> <input type="text" style="width: 95%;" name="col" value="" maxlength="7" > ';


echo'<div class="bbtn_sm mt5"><div class="br">
					<input type="submit" name="addadmin" value="Изменить">
				</div></div>';

echo '</span></li></ul>';



echo'</div></div></div></div></div></div></div>'; 
    
    
    
    

echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'restore/" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';

require_once ('../system/footer.php');
?>