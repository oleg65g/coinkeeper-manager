<?php


require_once ('system/header.php');




echo '<body><table style="width:100%;" cellspacing="0" cellpadding="0">
<tbody><tr><td style="padding:0 1px 0 0;"></td><td style="width: 52px;">
</td></tr></tbody></table><div class="center"></div><div></div>
<div style="color: #2b577f;" class="big content">Техработы...</div>
<div><img src="/images/index/teh.png" alt="" style="width:100%;"></div>
<div class="content">техработы не более 10 минут</div><div>

<a class="btnl" href="/">Обновить</a></div></body>';






require_once ('system/footer.php');

?> 