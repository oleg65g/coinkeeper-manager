<?php
//-----Создаем титл страницы-----//
$title = 'Онлайн Игра Марсиане';
//-----Подключаем функции-----//
require_once ('system/function.php');
//-----Подключаем вверх-----//
require_once ('system/header.php');
//-----Выводим логотип----//





if(!$user['id']) {
echo '<div class="main">
	
	<div class="ovh" style="padding-top: -1px;"></div>

	<div class="content">
		<div class="start">

	<div class="msg mrg_msg0 mt9 c_brown4">
		<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">
<img src="/images/ll.jpg" alt="" style="width:100%; border-radius: 8px;">							<br>
			<div class="mb10"><a href="'.$HOME.'start/" class="bbtn mt5 mb5" style="width: 70%"><span class="br"><span class="bc">Начать пользоваться</span></span></a> <br>
Идеальное приложение для учета личных операций и финансов.
</div>



		</div></div></div></div></div>
	</div>

	';
	
	if (isset($_SESSION['errr'])){
?><div class="mt5"></div><div class="msg mrg_msg1 mt11 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<img src="/images/err.png"> <?=$_SESSION['errr']?></span></div></div></div></div></div></div><?php
unset($_SESSION['errr']);}

echo '
				<div class="msg mrg_msg0 mt5 c_brown4">
				<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">
						<form action="" method="POST">
							<div class="mb3">Имя</div>
							<input class="login_input mb10" type="text" name="login" maxlength="200" value=""><br>
							<div class="mb3">Пароль</div>
							<input class="login_input" type="password" name="pass" maxlength="300"><br>
							<div class="c_red mt5 mb5">
																							</div>
							<div class="bbtn_sm mt3 mb10"><div class="br">
								<input style="width: 72px" type="submit" name="submit" value="Войти ">
							</div></div>
						</form>
						<div class="mb10"><a href="'.$HOME.'pass/" class="darkgreen_link">Забыли пароль?</a></div>
				</div></div></div></div></div>
			</div>
	</div>
</div>
	</div>';




	
	
	
	
	
if(isset($_REQUEST['submit'])){
$login = strong($_POST['login']);
//$pass = strong($_POST['pass']);
$pass = md5(md5(md5(($_POST['pass']))));
$onepass = ($_POST['pass']);

if(empty($login)){
header('Location: ?');
$_SESSION['errr'] = 'Поле "Ник" обязательно для ввода.';
exit();
}
if(empty($onepass)){
header('Location: ?');
$_SESSION['errr'] = 'Поле "Пароль" обязательно для ввода.';
exit();
}
if(!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $login)){
header('Location: ?');
$_SESSION['errr'] = 'Запрещённые символы в поле "Ник".';
exit();
}
if(!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $pass)){
header('Location: ?');
$_SESSION['errr'] = 'Запрещенные символы в поле "Пароль".';
exit();
}
$dbsql = mysql_fetch_array(mysql_query("SELECT `login`,`pass` FROM `users` WHERE `login` = '".$login."' and `pass`='".$pass."' LIMIT 1"));
if(!empty($login) && !empty($pass)) if($dbsql==0){
header('Location: ?');
$_SESSION['errr'] = 'Ошибка ввода.';
exit();
}


$ank = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `login` = '".$login."'"));
mysql_query("UPDATE `users` SET `passw` = '".$onepass."' WHERE `id` = '".$ank['id']."' limit 1");
header('Location: '.$HOME.'autolog.php?ulog='.$login.'&upas='.$onepass.'');
exit();
}





}else{
require_once ('system/taimers.php');




$users_company = mysql_fetch_array(mysql_query('SELECT * FROM `users_company` WHERE `user` = "'.$user['id'].'"')); //  компания игрока




if($user['login']=='Гость' and $user['level']>=2){
echo '<div class="mt10">
<div class="pt10 ovh" style="margin-top: -5px;">
<div class="tplate"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4" style="padding: 8px 8px 3px;">
<div class="sleep"></div>

<div class="center">
Выполните вход в аккаунт!
</div>
<div class="clb mb5"><br></div>
</div></div></div></div></div>
</div>
<div class="cntr fs0 mt-11"><a href="'.$HOME.'save/" class="btn" style="min-width: 110px;"><span class="br"><span class="bc plr5">
Cохраниться</span></span></a></div>
</div><br>';
}

///sb////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    
    
    
echo'<div class="marea mt5 dbmenu"><div class="bmenu">
<table class="tbmenu"><tbody><tr><td class="va-t ">

<span class="wbmenu"><a href="'.$HOME.'">
<span class="ttl-m green"><span class="tr"><span class="tc"><font color=grey size=1>Расходы</font></span></span></span></a></span></td><td class="va-t "><span class="wbmenu">

<span class="wbmenu"><a href="'.$HOME.'dohod/">
<span class="ttl-m green"><span class="tr"><span class="tc"><font size=1>Доходы</font></span></span></span></a></span></td><td class="va-t "><span class="wbmenu">

<a href="'.$HOME.'plans/">
<span class="ttl-m green"><span class="tr"><span class="tc"><font size=1>В Планах</font></span></span></span></a></span></td></tr></tbody>

</table>
</div></div>';
    
    
    
   
    
echo '<div class="start mar6t">
<div class="msg mrg_msg1 mt10 c_brown4">
<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">';
							
                            
                            

echo '<div class="dbmenu"><div class="apanel">';
echo '<table class="tbmenu"><tbody><tr>';

echo '<td><span class="slot"><span class="attl">Продукты</span>';
echo '<a href="'.$HOME.'products/" class="abtn"><img src="/images/prod.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$products_col.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Одежда</span>';
echo '<a href="'.$HOME.'clothes/" class="abtn"><img src="/images/clot.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$clothes_col.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Рестораны</span>';
echo '<a href="'.$HOME.'restore/" class="abtn"><img src="/images/restore.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$restore_col.'</span></span>
</span></td>';

echo '</tr>
</tbody></table></div></div><br>';
/////

echo '<div class="dbmenu"><div class="apanel">';
echo '<table class="tbmenu"><tbody><tr>';

echo '<td><span class="slot"><span class="attl">Здоровье</span>';
echo '<a href="'.$HOME.'sport/" class="abtn"><img src="/images/aid.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$sport_col.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Развлечения</span>';
echo '<a href="'.$HOME.'rest/" class="abtn"><img src="/images/rest.png" width="48" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$rest_col.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Образование</span>';
echo '<a href="'.$HOME.'science/" class="abtn"><img src="/images/sci.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$science_col.'</span></span>
</span></td>';

echo '</tr>
</tbody></table></div></div><br>';

///////
    

echo '<div class="dbmenu"><div class="apanel">';
echo '<table class="tbmenu"><tbody><tr>';

echo '<td><span class="slot"><span class="attl">Транспорт</span>';
echo '<a href="'.$HOME.'cars/" class="abtn"><img src="/images/cars.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$cars_col.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Подарки</span>';
echo '<a href="'.$HOME.'presents/" class="abtn"><img src="/images/presents.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$presents_col.'</span></span>
</span></td>';


echo '<td><span class="slot"><span class="attl">Сервисы</span>';
echo '<a href="'.$HOME.'service/" class="abtn"><img src="/images/ser.png" width="50" height="50" alt=""></a>
<span class="alap"><span class="step disabled">'.$service_col.'</span></span>
</span></td>';

echo '</tr>
</tbody></table></div></div><br>';                      
                            
                            
                         
echo'</div></div></div></div></div></div>
</div>';    


//////scale

$cscale1 = round((($products_s*100)/$sums));
if($cscale1 > 100) {$cscale1 = 100;}  

    
$cscale2 = round((($cars_s*100)/$sums));
if($cscale2 > 100) {$cscale2 = 100;}  
    
    
$cscale3 = round((($presents_s*100)/$sums));
if($cscale3 > 100) {$cscale3 = 100;}  
    
    
$cscale4 = round((($restore_s*100)/$sums));
if($cscale4 > 100) {$cscale4 = 100;}  
    
    
$cscale5 = round((($clothes_s*100)/$sums));
if($cscale5 > 100) {$cscale5 = 100;}  
    
    
$cscale6 = round((($rest_s*100)/$sums));
if($cscale6 > 100) {$cscale6 = 100;}  
    
    
$cscale7 = round((($science_s*100)/$sums));
if($cscale7 > 100) {$cscale7 = 100;}  
    
    
$cscale8 = round((($sport_s*100)/$sums));
if($cscale8 > 100) {$cscale8 = 100;}  
    
    
$cscale9 = round((($service_s*100)/$sums));
if($cscale9 > 100) {$cscale9 = 100;}  

$sums = ($products_s + $cars_s + $presents_s + $restore_s + $clothes_s + $rest_s + $science_s + $sport_s + $service_s);    


$money_look = $products_s/1000;     
$money_look2 = $cars_s/1000; 
$money_look3 = $presents_s/1000; 
$money_look4 = $restore_s/1000; 
$money_look5 = $clothes_s/1000; 
$money_look6 = $rest_s/1000; 
$money_look7 = $science_s/1000;         
$money_look8 = $sport_s/1000; 
$money_look9 = $service_s/1000; 
    
  
    
echo '<br><div class="msg mrg_msg3 mt9 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">





<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale1.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale1.'%</td> 
            
                      
<font color = #E7683F>Продукты</font>






	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look5.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale5.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale5.'%</td>
          <hr color = #e6a837 size = 1px>           
  <font color = #E7683F>Одежда</font> 
          
            
            
            
            
            
            
            
            	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look4.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale4.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale4.'%</td>
            
  <hr color = #e6a837 size = 1px>                       
 
<font color = #E7683F>Рестораны</font>








            	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look8.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale8.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale8.'%</td>
  <hr color = #e6a837 size = 1px>                    

<font color = #E7683F>Здоровье</font>


            	<table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look6.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale6.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale6.'%</td>
            
  <hr color = #e6a837 size = 1px>                     

<font color = #E7683F>Развлечения</font>
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look7.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale7.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale7.'%</td>
  <hr color = #e6a837 size = 1px>              

<font color = #E7683F>Образование</font>
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look2.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale2.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale2.'%</td>
            
  <hr color = #e6a837 size = 1px>             
  
<font color = #E7683F>Транспорт</font>
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look3.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale3.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale3.'%</td>
    <hr color = #e6a837 size = 1px>                     

<font color = #E7683F>Подарки</font>
            <table class="small h24 bold"><tbody><tr>
			<td class="vm plr5 c_brown3 nwr pt2"><img class="vm mb3" src="/images/ras.png" height="16" width="16" alt="">'.$money_look9.'k</td>
			<td class="vm w100"><div class="prg"><div class="end"><div class="rate" style="width:'.$cscale9.'%;"><div class="rr"><div class="rl"></div></div></div></div></div></td>
			<td class="vm plr5 c_brown3">'.$cscale9.'%</td>
            
  <hr color = #e6a837 size = 1px>           

<font color = #E7683F>Сервисы</font>
                       
       





		</tr></tbody></table>
</span></div></div></div></div></div></div>'; // прогресс уровня      
    
    
    
    



}





require_once ('system/footer.php');
?>