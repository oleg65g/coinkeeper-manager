<?php
require_once ('../system/function.php');
require_once ('../system/header.php');
if($user['id']) {
header('Location: /');
exit();
}

/*
if($_SERVER['REMOTE_ADDR'] != '130.180.212.167'){
$mult = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `ip` = '".strong($_SERVER['REMOTE_ADDR'])."' "),0);
if($mult >= 1){
header('Location: '.$HOME.' ');
$_SESSION['err'] = '<FONT COLOR=RED>Нарушениме правил соглашения!<br> Пункт: 2.6 ЗАПРЕЩАЕТСЯ Создавать дополнительные аккаунты.</FONT>';
exit();
}
}
*/



if(strong($_SERVER['REMOTE_ADDR']) == 0){
header('Location: '.$HOME.' ');
$_SESSION['err'] = '<FONT COLOR=RED>Ошибка регистрации. Попробуйте отключить VPN, или сменить браузер.</FONT>';
exit();
}

$baks = 1000;
$coin = 10000;
$sex = rand(1,2);
$pass = rand(1000000000,9000000000);
$viz = time()+1800;
$login = 'Гость';
mysql_query("INSERT INTO `users` SET `coin` = '".$coin."', `login` = 'Гость', `pass` = '".md5(md5(md5($pass)))."', `passw` = '".$pass."', `datareg` = '".time()."',`level` = '1', `viz` = '".$viz."', `last_update` = '".time()."'");


//-----Вычесляем id-----//
$uid = mysql_insert_id();




echo '<div class="main">
<div class="ovh" style="padding-top: -1px;"></div>
<div class="content">
<div class="start"><div class="msg mrg_msg0 mt9 c_brown4"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">
<img src="/images/ll.jpg" alt="" style="width:100%; border-radius: 8px;">
<div class="mb10"><a href="'.$HOME.'autolog.php?ulog='.$login.'&amp;upas='.$pass.'" class="bbtn mt5 mb5" style="width: 200px"><span class="br"><span class="bc">Продолжить</span></span></a>
</div></div></div></div></div></div></div>


<div class="msg mrg_msg0 mt5 c_brown4"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">

<div class=left>
    Очень простое приложение, выполнено в минималистическом стиле. Пользоваться им удобно и легко. Таких        счетов можно создавать сколько угодно. Программа отлично подойдёт новичкам.

</div>

</div></div></div></div></div></div></div></div></div>';
	

?>