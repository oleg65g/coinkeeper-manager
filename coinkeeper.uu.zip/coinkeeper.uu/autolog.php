<?php
require_once ('system/function.php');
require_once ('system/header.php');
if($user['id']){
header('Location: /');
exit();
}




if (empty($_GET['ulog']) and empty($_GET['upas'])){
$login = strong($_POST['login']);//фильтрируем
$pass = md5(md5(md5(strong($_POST['pass'])))); //фильтрируем
} else {
$login = strong($_GET['ulog']);
$pass = md5(md5(md5(strong($_GET['upas']))));
}

$sql = mysql_query("SELECT `login` FROM `users` WHERE `login` = '".$login."' and `pass` = '".$pass."' LIMIT 1");
$dbsql = mysql_fetch_array(mysql_query("SELECT `login`,`pass` FROM `users` WHERE `login` = '".$login."' and `pass`='".$pass."' LIMIT 1"));

if(mysql_num_rows($sql)){			
setcookie('uslog', $dbsql['login'], time()+86400*31, '/');
setcookie('uspass', $pass, time()+86400*31, '/');
header('Location: /');
exit();
}else{



if(empty($login)){
header('Location: /');
$_SESSION['err'] = 'Поле "Ник" обязательно для ввода.';
exit();
}
if(empty($pass)){
header('Location: /');
$_SESSION['err'] = 'Поле "Пароль" обязательно для ввода.';
exit();
}
if(!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $login)){
header('Location: /');
$_SESSION['err'] = 'Запрещённые символы в поле "Ник".';
exit();
}
if(!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $pass)){
header('Location: /');
$_SESSION['err'] = 'Запрещенные символы в поле "Пароль".';
exit();
}
if(!empty($login) && !empty($pass)) if($dbsql==0) {
header('Location: /');
$_SESSION['err'] = 'Ошибка ввода.';
exit();
}

}

?>