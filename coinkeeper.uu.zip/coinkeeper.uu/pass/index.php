<?php
$title = 'Восстановление пароля';
require_once ('../system/function.php');
require_once ('../system/header.php');


//-----Если жмут submit(кнопку)-----//
if(isset($_REQUEST['submit'])){
$login = strong($_POST['login']);
$email = strong($_POST['email']);


if(empty($login)){
$_SESSION['err_pass'] = 'Поле "Логин" обязательно для ввода.';
header('Location: '.$HOME.'pass/');
exit();
}
if(mb_strlen($login) > 30 or mb_strlen($login) < 3){
header('Location: '.$HOME.'pass/');
$_SESSION['err_pass'] = ' Поле "Логин" должно содержать от 3 до 15 символов. ';
exit();
}
if (!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $login)){
header('Location: '.$HOME.'pass/');
$_SESSION['err_pass'] = 'Поле "Логин" должно содержать только Русские или Английские буквы, цифры.';
exit();
}
if(empty($email)){
header('Location: '.$HOME.'pass/');
$_SESSION['err_pass'] = ' Поле "Email" обязательно для ввода. ';
exit();
}
if (!preg_match('/[0-9a-z_\-]+@[0-9a-z_\-^\.]+\.[a-z]{2,6}/i', $email)) {
header('Location: '.$HOME.'pass/');
$_SESSION['err_pass'] = 'Поле "Email" заполнено не верно.';
exit();
}
$sqldb_login = mysql_fetch_array(mysql_query("SELECT `login` FROM `users` WHERE `login` = '".$login."' LIMIT 1"));
if(!empty($login)) if($sqldb_login == 0){
header('Location: '.$HOME.'pass/');
$_SESSION['err_pass'] = ' Пользователь с таким Логином не найден. ';
exit();
}
$sqldb_email = mysql_fetch_array(mysql_query("SELECT `email` FROM `users` WHERE `email`='".$email."' LIMIT 1"));
if(!empty($email)) if($sqldb_email == 0){
header('Location: '.$HOME.'pass/');
$_SESSION['err_pass'] = ' Пользователь с таким Email-адресом не найден. ';
exit();
}
$sqldb = mysql_fetch_array(mysql_query("SELECT `login`,`email` FROM `users` WHERE `login` = '".$login."' and `email`='".$email."' LIMIT 1"));
if(!empty($login) && !empty($email)) if($sqldb == 0){
header('Location: '.$HOME.'pass/');
$_SESSION['err_pass'] = ' Веденные данные не совпадают. ';
exit();
}


function make_password($num_chars){
if ((is_numeric($num_chars)) && ($num_chars > 0) && (!is_null($num_chars))){
$password = ""; 
$accepted_chars="abcGdefghHiFXZBVNPERRGjklmnUopqGGFGrstHuvwKxyzl234567890"; 
if (necessary.srand(((int)((double)microtime()*100000000000003)))); 
for ($i= 0; $i < $num_chars; $i++){ 
$random_number = rand(0, (strlen($accepted_chars)-1)); $password .= $accepted_chars[$random_number]; 
} 
return $password; 
} 
} 
$dlina=8; //количество символов в пароле 
$rou = make_password($dlina); 


mysql_query("UPDATE `users` SET `pass` = '".md5(md5(md5($rou)))."' WHERE `login` = '".$login."'");

$title = 'От support@airbiz.ru';
$msg = 'Здравствуйте, '.$login.'!
Вами (или нет) была произведена операция по восстановлению пароля на сайте '.$HOME.'

Ваши новые данные для авторизации:
-------------------------
Логин: '.$login.'
Пароль: '.$rou.'
-------------------------

Пароль сгенирировался автоматически, просим Вас после авторизации сменить его!

С Уважением, '.$NameGame.' !
Служба поддержки: support@airbiz.ru


Время заявки: '.date("Y-m-d H:i:s").'
Устройство: '.strong($_SERVER['HTTP_USER_AGENT']).'
IP устройства: '.strong($_SERVER['REMOTE_ADDR']).' ';

$subject = 'Восстановление доступа';
mail($email, $subject, $msg);
/*
<?php 
mail("testfozzy.testfozzy@outlook.com", "My Subject", "Line 1\nLine 2\nLine 3"); 
?>
*/
//mail($email,$subject,$msg,"From: '.$NameGame.'");
header('Location: '.$HOME.'pass/');
$_SESSION['okpass'] = 'На указанный Email-адрес  '.$email.'  было выслано письмо с Вашими новыми регистрациоными данными. <br> <font color=black>(Проверяйте так же папку "Спам"!) ';
exit();
}







echo'<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">Восстановление доступа</div></div></div>';

if (isset($_SESSION['okpass'])){
?><div class="msg mrg_msg1 mt11 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<img src="/images/ok.png"> <?=$_SESSION['okpass']?></span></div></div></div></div></div></div><?php
unset($_SESSION['okpass']);}

if (isset($_SESSION['err_pass'])){
?><div class="msg mrg_msg1 mt11 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="green_dark bold">
<img src="/images/err.png"> <?=$_SESSION['err_pass']?></span></div></div></div></div></div></div><?php
unset($_SESSION['err_pass']);}


echo '
<div class="msg mrg_msg0 mt5 c_brown4">
<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">
<form action="" method="POST">
<div class="mb3">Логин</div>
<input class="login_input mb10" type="text" name="login" maxlength="20" value=""><br>
<div class="mb3">Пароль</div>
<input class="login_input" type="email" name="email" maxlength="30"><br>
<div class="c_red mt5 mb5">
</div>
<div class="bbtn_sm mt5"><div class="br"><input type="submit" name="submit" value="Восстановить"></div></div>
</form>
</div></div></div></div></div></div>';


echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'" class="mb_ttl back">На главную</a></div></div></div>
</div></div></div></div></div></div>';

require_once ('../system/footer.php');
?>