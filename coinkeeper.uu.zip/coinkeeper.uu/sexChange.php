<?php
$title = 'Смена пола';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: /');
exit();
}

echo'<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">'.$title.'</div></div></div>';



if($user['sex'] == 1){
$pol =    'Мужской'    ;
}else{
$pol =    'Женский'    ;
}

if(isset($_REQUEST['ok'])){
$sex = strong($_POST['sex']);
mysql_query("UPDATE `user_avatars` SET `sex` = '".$sex."', `images` = '1', `ust` = '1' WHERE `id` = '".$user_avatars['id']."'");
mysql_query("UPDATE `users` SET `sex` = '".$sex."' WHERE `id` = '".$user['id']."'");
header('Location: ?');
$_SESSION['ok'] = 'Настройки успешно изменены!';
exit();
}





echo'<div class="msg mrg_msg1 mt10 c_brown"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4"><span class="darkgreen_link">


<div class="bordered">
<div class="mt4 center">



<center><form action="" method="POST">
Ваш пол: '.$pol.' <br> <select name="sex" style="width: 100%;"><option value="1">Мужской</option><option value="2">Женский</option></select>



				<div class="bbtn_sm mt5"><div class="br">
					<input type="submit" name="ok" value="Сменить пол">
				</div></div>
</span> 
</div>
';






echo'</div></div></div></div></div></div></div>
';








echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'settings/" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';



require_once ('../system/footer.php');
?>