<?php
$title = 'Техподдержка';
//-----Подключаем функции-----//
require_once ('../system/function.php');
//-----Подключаем вверх-----//
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: /');
exit();
}

if(!$komnata and $user['status'] == 0){
header('Location: '.$HOME.'tikets/');
exit();
}


$id = abs(intval($_GET['id']));
$tiket = mysql_fetch_assoc(mysql_query("SELECT * FROM `tikets` WHERE `id` = '".$id."'"));


if($tiket==0){
header('Location: /');
$_SESSION['err'] = 'Запись не найдена.';
exit();
}
if($user['status'] == 0){
if($tiket['id'] != $komnata['id']){
header('Location: '.$HOME.'chat_mod/'.$komnata['id'].'/');
exit();
}
}


$ank = mysql_fetch_array(mysql_query('SELECT * FROM `tikets_msg` WHERE `ank` = "'.$ank['id'].'"   '));
$pm_dialog = mysql_fetch_array(mysql_query('SELECT * FROM `tikets` WHERE `user` = "'.$user['id'].'"'));
$n_tiket2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `tikets_msg` WHERE `user` = '".$tiket['id']."' and `tiket_new` = '1' "),0);


if(isset($_REQUEST['add'])) {
    
$msg = strong($_POST['msg']);
    
If($Ignore){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Общение не доступно.</font>';
exit();
}
If($ban){
header('Location: ?');
$_SESSION['err'] = '<font color=red>Общение не доступно.</font>';
exit();
}     
if(empty($msg)) {
header('Location: ?');
$_SESSION['err'] = '<font color=red>Введите сообщение.</font>';
exit();
}    
    
    
 //// нов сообщен
mysql_query("INSERT INTO `tikets_msg` SET `msg` = '".$msg."', `user` = '".$user['id']."', `time` = '".time()."', `komnata_id` = '".$tiket['id']."'");
    
mysql_query("UPDATE `tikets` SET `time` = '".time()."' WHERE `id` = '".$tiket['id']."'");     
mysql_query("INSERT INTO `tikets_files` SET `user` = '".$user['id']."', `msg_id` = '".$tiket['id']."'");
if($user['status']==0){
mysql_query("UPDATE `users` SET `tiket_m` = '1' WHERE `id` and `status` > '0' LIMIT 1");
}else{
mysql_query("UPDATE `tikets_msg` SET `tiket_new` = '1' WHERE `komnata_id` = '".$tiket['id']."' LIMIT 1"); 
}



//// оповищение от админа
if($user['status']>0){
$msg1 = 'Служба поддержки обработала ваш запрос!';
$pm_dialog = mysql_fetch_array(mysql_query('SELECT * FROM `pm_dialog` WHERE `user` = "'.$tiket['user'].'" and `ank` = "2"  or `user` = "2" and `ank` = "'.$tiket['user'].'" '));
if($pm_dialog){
mysql_query("INSERT INTO `pm_msg` SET `user` = '2', `ank` = '".$tiket['user']."', `msg` = '".$msg1."', `time` = '".time()."', `dialog` = '".$pm_dialog['id']."'");
}else{
mysql_query("INSERT INTO `pm_dialog` SET `user` = '2', `ank` = '".$tiket['user']."' ");
$uid = mysql_insert_id();
mysql_query("INSERT INTO `pm_msg` SET `user` = '2', `ank` = '".$tiket['user']."', `msg` = '".$msg1."', `time` = '".time()."', `dialog` = '".$uid."'");
}
}



header('Location: ?');
$_SESSION['ok'] = 'Сообщение отправлено!';
exit();
}
//// вивод крас кнопки
if($user['status']==0 and $n_tiket2 > 0){
mysql_query("UPDATE `tikets_msg` SET `tiket_new` = '0' WHERE `id` = '".$tiket['id']."'  ");  
}
if($user['status']>0){
mysql_query("UPDATE `users` SET `tiket_m` = '0' WHERE `id` LIMIT 1");
}





echo '<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">Служба поддержки </div></div></div>';

echo '<div class="msg mlr5 mt10 c_brown4">
	<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 left p10">';

echo '<center><form action="" method="POST">
<br><textarea style="width: 95%;" name="msg" id="message"></textarea><br>';


////
?>


				<div class="bbtn_sm mt5"><div class="br">
					<input type="submit" name="add" value="Написать">
				</div></div>


<span id="pokazat">

<div class="fight center">
<?
$sm = mysql_query("SELECT * FROM `smile` WHERE `papka` = '1' ORDER BY `id` ASC");
while($s = mysql_fetch_assoc($sm)){
?>
<a onclick="pasteSmile(' <?=$s['name']?> ')"><img src="<?=$HOME?>files/smile/<?=$s['icon']?>" alt="<?=$s['name']?>" title="<?=$s['name']?>"></a>
<?
}
?>
<br></div></span></center></form><br><div class="hr"></div><br>
<?










echo '</span></li></ul>';

if (empty($user['max'])) $user['max']=10;
$max = 10;
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `tikets_msg` WHERE `komnata_id` = '".$tiket['id']."'"),0);
$k_page = k_page($k_post,$max);
$page = page($k_page);
$start = $max*$page-$max;
$k_post = $start+1;
$query = mysql_query("SELECT * FROM `tikets_msg` WHERE  `komnata_id` = '".$tiket['id']."'   ORDER BY `id` DESC LIMIT $start,$max");
while($post = mysql_fetch_assoc($query)){
    
$komu = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$post['id_komu']."'"));
$usr = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$post['avtor']."'"));

    
if(isset($_GET['del'.$post['id'].''])) {
if($user['status']!=2){
header('Location: ?');
$_SESSION['err'] = 'Ошибка';
exit();
}     
mysql_query("DELETE FROM `tikets_msg` WHERE `id` = '".$post['id']."'");    
header('Location: ?');
exit();
}       
    
if($usr['level'] >= 1){
$mmm = filter(bb(smile($post['msg'])));
}else{
$mmm = filter(bb1(smile($post['msg'])));
}
//////////

    

    
//////////
if($post['avtor'] == $user['id'] and $post['id_komu'] != 0){
$name = '<b>'.$komu['login'].'</b> '.$mmm.'';
}

if($post['avtor'] == $user['id'] and $post['id_komu'] == 0){
$name = ''.$mmm.'';
}

if($post['avtor'] != $user['id'] and $post['id_komu'] != $user['id']){
$name = ''.$komu['login'].' '.$mmm.'';
}

if($post['avtor'] != $user['id'] and $post['id_komu'] == $user['id']){
$name = '<font color=red>'.$komu['login'].' '.$mmm.'';
}

echo''.$del.' <span style="float: right;">  <font size=1 color=grey> '.times($post['time']).'</font></span> '.nick($post['user']).'';



echo '<br>';
if($user['status']==2){
echo'<div class="fr"><a href="?del'.$post['id'].'"><font color = red>X</font></a></div>';
}
if($post['id_komu'] == $komu['id']){
echo ' '.$name.'</font>';
}else{
echo''.$mmm.'';
}

echo'<hr>';


}






  
echo '</div></div></div></div></div>
</div>';


if(isset($_GET['delall'.$tiket['id'].''])) {

if($user['status']!=2){
header('Location: ?');
$_SESSION['err'] = 'Ошибка';
exit();
}    
mysql_query("DELETE FROM `tikets_msg` WHERE `komnata_id` = '".$tiket['id']."'"); 
mysql_query("DELETE FROM `tikets` WHERE `id` = '".$tiket['id']."'");  
header('Location: '.$HOME.'tikets/');
exit();
}  

 


if($user['status']==2){
echo'<div class="marea mt5"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">';
echo '<div class="mbtn orange"><div class="mb_r"><div class="mb_c"><a href="?delall'.$tiket['id'].'" class="mb_ttl error"><font color = red>Удалить тикет</font></a></div></div></div>';
echo '</div></div></div></div></div>
</div>';
echo '</div></div></div></div></div></div>';
}


if ($k_page > 1) {
echo str(''.$HOME.'chat_mod/'.$tiket['id'].'/?',$k_page,$page); // Вывод страниц
}  

if($user['status']<1){
echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';
}else{
echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'tikets/" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';
}


require_once ('../system/footer.php');
?>