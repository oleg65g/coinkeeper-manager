<?php
$title = 'Техподдержка';
//-----Подключаем функции-----//
require_once ('../system/function.php');
//-----Подключаем вверх-----//
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: /');
exit();
}


//если в игноре
if($Ignore){
echo '<div class="msg mrg_msg1 mt10 c_brown4"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
<table class="pet_profile"><tbody>';
echo '<div class="center mb5 c_red"><span class="orange_dark2 font_13">Общение не доступно <span> <font color=black>'.vremja($Ignore['time_end']).'</font> </span></span></div><div class="hr"></div>
<div class="center mt5"><a class="large darkgreen_link" href="?">Обновить</a></div><br>';
echo '</div></div></div></div></div>
</div></tbody></table>
</div></div></div></div></div></div>'; 
}else{
if($komnata and $user['status'] == 0) {
header('Location: '.$HOME.'chat_mod/'.$komnata['id'].'/');
exit();
}

if(isset($_GET['chat_modd'])){
    

  
if($komnata ) {
header('Location: /');
exit();
}
mysql_query("INSERT INTO `tikets` SET `user` = '".$user['id']."', `time` = '".time()."'");

$uid = mysql_insert_id();
header('Location: '.$HOME.'chat_mod/'.$uid.'/');
exit();
}


echo '<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">'.$title.'</div></div></div>';
    
if($user['status'] !=2){    
if(!$komnata) {
echo'<div class="msg mrg_msg1 mt5 c_brown4">
	<div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4 font_14">
				<div>Если вопросы остались, напишите нам</div>
		<center><a href="'.$HOME.'tikets/?chat_modd" class="bbtn mt5 mb5 "><span class="br"><span class="bc">Задать вопрос</span></span></a></center>
	</div></div></div></div></div>
</div>';
}
}
    


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


if($user['status'] > 0){
if (empty($user['max'])) $user['max']=10;
$max = 10;
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `tikets` WHERE `id`"),0);
$k_page = k_page($k_post,$max);
$page = page($k_page);
$start = $max*$page-$max;
$k_post = $start+1;
$pm_dialog = mysql_query("SELECT * FROM `tikets` WHERE `id`  ORDER BY `time` DESC LIMIT $start,$max");
while($p_d = mysql_fetch_assoc($pm_dialog)){
    
$col_msg = mysql_result(mysql_query('SELECT COUNT(*) FROM `tikets_msg` WHERE `komnata_id` = "'.$p_d['id'].'" '),0);
    
$pm_msg_ = mysql_query('SELECT * FROM `tikets_msg` WHERE `komnata_id` = "'.$p_d['id'].'" ORDER BY `id` DESC LIMIT 1 ');
$pm_msg = mysql_fetch_array($pm_msg_); 
    

if($col_msg){
$mm = ($pm_msg['msg']);


}else{
$mm = 'Перейти к сообщению';
}
    
    
echo'<div class="msg mrg_msg1 mt10 c_brown4">
	<div class="wr_bg no_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3 no_bg"><div class="wr_c4 no_bg p10">
		<div class="posters font_14">
								<div class="poster mb3">
<div class="post_lint2 mb3">
<div class="pl_cont">'.nick($p_d['user']).'</div>
<div class="pl_date">'.vremja($p_d['time']).'</div>
<hr>
<a href="'.$HOME.'chat_mod/'.$p_d['id'].'/" class="read_post mw"><font color=#b14700>'.filter(smile($mm)).'</font></a>

</div></div></div>
<div class="pgn"></div>
</div></div></div></div></div>
</div>';

}

}
}

if ($k_page > 1) {
echo str(''.$HOME.'tikets/?',$k_page,$page); // Вывод страниц
}  

echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">
		<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'" class="mb_ttl back">Вернуться</a></div></div></div>
</div></div></div></div></div></div>';


require_once ('../system/footer.php');
?>